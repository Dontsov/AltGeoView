HDFSTRUCT

This script accesses an HDF file and displays information about its contents.  
The file is specified at the command line.

TODO: Better documentation
